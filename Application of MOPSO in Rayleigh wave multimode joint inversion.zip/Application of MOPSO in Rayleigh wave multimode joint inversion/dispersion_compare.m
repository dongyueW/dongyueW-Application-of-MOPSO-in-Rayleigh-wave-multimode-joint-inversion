clear all;
clc;
global f n vs vp dns thk  thk1 vs1 vp1 dns1
n=30;
f1=log(5.0);
f2=log(100.0);
df=(f2-f1)/(n-1);
for i=0:n-1
    ff=exp(f1+i*df);
    freq(i+1)=ff;
end
freq=freq';
mf=length(freq);
nv=100;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dns = [1.8 1.8 1.8 1.8 1.8 1.8];
poisson = [0.45 0.45 0.45 0.45 0.45 0.45];

vs = [194.412182997696,268.516736811261,364.192147532145,467.578773147648,598.320851141506,739.915233230834];
thk = [2.40764794584545,2.32807729589252,2.29958987568233,2.24550381300256,3.90198706843889];
vp = vs.*sqrt((2-2*poisson)./(1-2*poisson));
for j=1:mf
    f=freq(j);
    for i=1:nv
        dv=(max(vs)-0.8*min(vs))/nv;
        vr=0.8*min(vs)+(i-1)*dv;
        v(i)=vr;
        F(i,j)=fastx3n_3(vr);
    end
end
v=v'; 
vrobs=zeros(mf,5);

for j=1:mf
    k=1;
    f=freq(j);
    for i=2:nv
        if F(i-1,j)*F(i,j)<0        
           vrobs(j,k)=fzero('fastx3n_3',[v(i-1),v(i)]);
           k=k+1;
        end
    end
end
figure;
n1indexobs=find(vrobs(:,1));
vrobs1=vrobs(n1indexobs,1)';
plot(freq(n1indexobs),vrobs1,'r-','LineWidth',2);
xlabel('Frequency(Hz)'); ylabel('Phase Velocity(m/s)');  %0
hold on;

n2indexobs=find(vrobs(:,2));
vrobs2=vrobs(n2indexobs,2)';
plot(freq(n2indexobs),vrobs2,'r:','LineWidth',2);    %1

n3indexobs=find(vrobs(:,3));
vrobs3=vrobs(n3indexobs,3)';
plot(freq(n3indexobs),vrobs3,'r:','LineWidth',2);    %2

hold on;


%%%%%%%%%%%%%%%%%%理论模型%%%%%%%%%%蓝色
thk = [2.4 2.4 2.4 2.4 3.6];
dns = [1.8 1.8 1.8 1.8 1.8 1.8];
poisson = [0.45 0.45 0.45 0.45 0.45 0.45];
vs = [194 270 367 485 603 740];
vp = vs.*sqrt((2-2*poisson)./(1-2*poisson));
for j=1:mf
    f=freq(j);
    for i=1:nv
        dv=(max(vs)-0.8*min(vs))/nv;
        vr=0.8*min(vs)+(i-1)*dv;
        v(i)=vr;
        F(i,j)=fastx3n_3(vr);
    end
end
v=v'; 
vrobs=zeros(mf,5);

for j=1:mf
    k=1;
    f=freq(j);
    for i=2:nv
        if F(i-1,j)*F(i,j)<0        
           vrobs(j,k)=fzero('fastx3n_3',[v(i-1),v(i)]);
           k=k+1;
        end
    end
end

n1indexobs=find(vrobs(:,1));
vrobs1=vrobs(n1indexobs,1)';
plot(freq(n1indexobs),vrobs1,'b*','LineWidth',2);
xlabel('Frequency(Hz)'); ylabel('Phase Velocity(m/s)');  %0
hold on;

n2indexobs=find(vrobs(:,2));
vrobs2=vrobs(n2indexobs,2)';
plot(freq(n2indexobs),vrobs2,'bd','LineWidth',2);    %1

n3indexobs=find(vrobs(:,3));
vrobs3=vrobs(n3indexobs,3)';
plot(freq(n3indexobs),vrobs3,'bx','LineWidth',2);  %2



clear all;
