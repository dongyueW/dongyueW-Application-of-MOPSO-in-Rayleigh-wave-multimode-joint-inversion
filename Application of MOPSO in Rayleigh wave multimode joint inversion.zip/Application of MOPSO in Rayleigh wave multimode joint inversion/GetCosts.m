function costs=GetCosts(pop)

    nobj=numel(pop(1).Cost);
    costs=reshape([pop.Cost],nobj,[]); %例如，如果 A 是一个 10×10 矩阵，则 reshape(A,2,2,[])
                                       % 将 A 的 100 个元素重构为一个 2×2×25 数组。

end