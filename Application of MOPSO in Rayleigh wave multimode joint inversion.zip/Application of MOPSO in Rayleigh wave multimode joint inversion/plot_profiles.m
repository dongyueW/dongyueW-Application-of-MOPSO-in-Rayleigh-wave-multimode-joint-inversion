
tic;
clc;
clear all;

vnumber=6;
hnumber=vnumber-1;
  LB=[100 150 200 250 300 500 1.2 1.2 1.2 1.2 1.8];
Ture=[194 270 367 485 603 740 2.4 2.4 2.4 2.4 3.6];
  UB=[400 400 500 600 700 900 3.6 3.6 3.6 3.6 5.4];
aver=[194.412182997696,268.516736811261,364.192147532145,467.578773147648,598.320851141506,739.915233230834,2.40764794584545,2.32807729589252,2.29958987568233,2.24550381300256,3.90198706843889];

  
  figure ;
hold on
h(1)=plotprofile(Ture,'b-',2);
h(2)=plotprofile(aver,'m:',2);
h(3)=plotprofile([LB(1:vnumber),UB((vnumber+1):(vnumber+hnumber))],'r--',2);
plotprofile([UB(1:vnumber),LB((vnumber+1):(vnumber+hnumber))],'r--',2);

view(0,-90);
axis([0 950 0 20]);
xlabel('S-wave velocity (m/s)','fontname','Times New Roman','FontSize',5);
ylabel('Depth (m)','fontname','Times New Roman','FontSize',5);
legend(h([3 1 2]),'Limit','True','Inverted','fontname','Time New Roman','FontSize',16);
set(gca,'FontName','Times New Roman','FontSize',16);
set(gca,'Xcolor',[0,0,0]);
set(gca,'Ycolor',[0,0,0]);
%title('(b) ','fontname','Times New Roman','FontSize',15,'position',[110 19]);
set(legend,...
    'Position',[0.694047622453598 0.795634923331321 0.18749999659402 0.101190473494076],'FontSize',15);
box on