load ('The array extracted from Symmetric_model.mat') ; %Symmetric model
b = cat(1,Position{:});
Aver= mean(b);   %'Aver' As a final result