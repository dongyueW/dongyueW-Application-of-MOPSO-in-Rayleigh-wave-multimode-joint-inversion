clc;
clear;
close all;

      for t=1:5

        



CostFunction=@(x) Rayleigh_fitness(x);
        nVar=11;
        VarMin=[100 150 200 250 300 500 1.2 1.2 1.2 1.2 1.8];
        VarMax=[400 400 500 600 700 900 3.6 3.6 3.6 3.6 5.4];
        


VarSize=[1 nVar];

VelMax=(VarMax-VarMin)/10;

%% MOPSO ����
nPop=100;   % Population Size

nRep=nVar*5;   % Repository Size

MaxIt=85;  % Maximum Number of Iterations

phi1=2.05;
phi2=2.05;
phi=phi1+phi2;
chi=2/(phi-2+sqrt(phi^2-4*phi)); 
w=chi;              % Inertia Weight
wdamp=0.99;            % Inertia Weight Damping Ratio
c1=chi*phi1;        % Personal Learning Coefficient
c2=chi*phi2;        % Global Learning Coefficient

alpha=0.1;      % Grid Inflation Parameter

nGrid=7;   % Number of Grids per each Dimension

beta=2;     % Leader Selection Pressure Parameter

gamma=2;    % Extra (to be deleted) Repository Member Selection Pressure

%% ��ʼ��

particle=CreateEmptyParticle(nPop);

for i=1:nPop
    particle(i).Velocity=0;
    particle(i).Position=unifrnd(VarMin,VarMax,VarSize); %unifrnd��[VarMin,VarMax]����ģ��VarSize������
    % ��ʼ�����Ա���X��λ��
    particle(i).Cost=CostFunction(particle(i).Position); % ���Ŀ�꺯��
    particle(i).Best.Position=particle(i).Position;
    particle(i).Best.Cost=particle(i).Cost;
end

particle=DetermineDomination(particle);

rep=GetNonDominatedParticles(particle);

rep_costs=GetCosts(rep);
G=CreateHypercubes(rep_costs,nGrid,alpha);

for i=1:numel(rep)
    [rep(i).GridIndex ,rep(i).GridSubIndex]=GetGridIndex(rep(i),G);
end
    
%% MOPSO ��ѭ��

for it=1:MaxIt
    
    for i=1:nPop
       
        rep_h=SelectLeader(rep,beta);

        particle(i).Velocity=w*particle(i).Velocity ...
                             +c1*rand*(particle(i).Best.Position - particle(i).Position) ...
                             +c2*rand*(rep_h.Position -  particle(i).Position);

        particle(i).Velocity=min(max(particle(i).Velocity,-VelMax),+VelMax);

        particle(i).Position=particle(i).Position + particle(i).Velocity;
    
        flag=(particle(i).Position<VarMin | particle(i).Position>VarMax);    %���Ӽ��:flag
        particle(i).Velocity(flag)=-particle(i).Velocity(flag);
        
        particle(i).Position=min(max(particle(i).Position,VarMin),VarMax);

        particle(i).Cost=CostFunction(particle(i).Position);

        if Dominates(particle(i),particle(i).Best)
            particle(i).Best.Position=particle(i).Position;
            particle(i).Best.Cost=particle(i).Cost;
            
        elseif ~Dominates(particle(i).Best,particle(i))
            if rand<0.5
                particle(i).Best.Position=particle(i).Position; 
                particle(i).Best.Cost=particle(i).Cost;
            end
        end

    end
    
    particle=DetermineDomination(particle);
    nd_particle=GetNonDominatedParticles(particle);
    
    rep=[rep
         nd_particle];
    
    rep=DetermineDomination(rep);
    rep=GetNonDominatedParticles(rep);
    
    for i=1:numel(rep)
        [rep(i).GridIndex rep(i).GridSubIndex]=GetGridIndex(rep(i),G);
    end
    
    if numel(rep)>nRep
        EXTRA=numel(rep)-nRep;
        rep=DeleteFromRep(rep,EXTRA,gamma);
        
        rep_costs=GetCosts(rep);
        G=CreateHypercubes(rep_costs,nGrid,alpha);
        
    end
   
   disp(['Iteration ' num2str(it) ': Number of Repository Particles = ' num2str(numel(rep))]);
    
    w=w*wdamp;
end

%% ���




costs=GetCosts(particle);
rep_costs=GetCosts(rep);

figure;

plot3(costs(1,:),costs(2,:),costs(3,:),'b.');
hold on;
plot3(rep_costs(1,:),rep_costs(2,:),rep_costs(3,:),'rx');
legend('Main Population','Repository');



    filename = sprintf('Inversion model%s.mat', num2str(t));
    save (filename);
end
