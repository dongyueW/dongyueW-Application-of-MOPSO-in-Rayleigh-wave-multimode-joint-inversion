%% %%%%%ģ��������Ƴ���%%%%%
%% by ��ΰ 2016.7.28
function h=plotprofile(model,color,linewidth)
    n=(length(model)+1)/2;
    for i=1:n
        x(2*i-1)=model(i);
        x(2*i)=model(i);
    end
    for i=n+1:2*n-1
        sum1=sum(model(n+1:i));
        y(2*(i-n))=sum1;
        y(2*(i-n)+1)=sum1;
    end
    y(2*n)=30;
    h=plot(x,y,color,'linewidth',linewidth);
end
